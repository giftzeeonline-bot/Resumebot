100 fictional resumes for testing resume-search software.
Every person, organization, work history, and contact detail is synthetic.
Each PDF is two pages and approximately 800-1,200 words.
